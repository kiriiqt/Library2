﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibraryManagementSystem
{
    public partial class AddBooks : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\God is Good\OneDrive\Documents\System.mdf;Integrated Security=True;Connect Timeout=30");

        public AddBooks()
        {
            InitializeComponent();
            displayBooks();
        }

        public void refreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }

            displayBooks();
        }

        private String imagePath;

        // Import book image
        private void addBooks_importBtn_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "Image Files (*.jpg; *.png)|*.jpg;*.png";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    imagePath = dialog.FileName;
                    addBooks_picture.ImageLocation = imagePath;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Add new book
        private void addBooks_addBtn_Click(object sender, EventArgs e)
        {
            if (addBooks_picture.Image == null
                || string.IsNullOrEmpty(addBooks_bookTitle.Text)
                || string.IsNullOrEmpty(addBooks_author.Text)
                || addBooks_published.Value == null
                || string.IsNullOrEmpty(addBooks_status.Text))
            {
                MessageBox.Show("Please fill all fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    // Ensure connection is closed and open
                    if (connect.State == ConnectionState.Closed)
                    {
                        connect.Open();
                    }

                    DateTime today = DateTime.Today;

                    // Generate image path
                    string imageSavePath = Path.Combine(@"C:\Users\God is Good\source\repos\LibraryManagementSystem\LibraryManagementSystem\Books_Directory",
                                                        addBooks_bookTitle.Text + addBooks_author.Text.Trim() + ".jpg");

                    // Ensure the directory exists
                    string directoryPath = Path.GetDirectoryName(imageSavePath);
                    if (!Directory.Exists(directoryPath))
                    {
                        Directory.CreateDirectory(directoryPath);
                    }

                    // Copy image to directory
                    File.Copy(addBooks_picture.ImageLocation, imageSavePath, true);

                    // Insert book data into database
                    string insertData = "INSERT INTO books (book_title, author, published_date, status, image, date_insert) " +
                                        "VALUES(@bookTitle, @author, @published_date, @status, @image, @dateInsert)";

                    using (SqlCommand cmd = new SqlCommand(insertData, connect))
                    {
                        cmd.Parameters.AddWithValue("@bookTitle", addBooks_bookTitle.Text.Trim());
                        cmd.Parameters.AddWithValue("@author", addBooks_author.Text.Trim());
                        cmd.Parameters.AddWithValue("@published_date", addBooks_published.Value);
                        cmd.Parameters.AddWithValue("@status", addBooks_status.Text.Trim());
                        cmd.Parameters.AddWithValue("@image", imageSavePath);
                        cmd.Parameters.AddWithValue("@dateInsert", today);

                        cmd.ExecuteNonQuery();
                        displayBooks();

                        MessageBox.Show("Book added successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        clearFields();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // Ensure connection is closed properly after operation
                    if (connect.State == ConnectionState.Open)
                    {
                        connect.Close();
                    }
                }
            }
        }

        // Clear fields
        public void clearFields()
        {
            addBooks_bookTitle.Clear();
            addBooks_author.Clear();
            addBooks_picture.Image = null;
            addBooks_status.SelectedIndex = -1;
        }

        // Display all books
        public void displayBooks()
        {
            try
            {
                // Ensure connection is open
                if (connect.State == ConnectionState.Closed)
                {
                    connect.Open();
                }

                string selectQuery = "SELECT * FROM books WHERE date_delete IS NULL";
                SqlDataAdapter adapter = new SqlDataAdapter(selectQuery, connect);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Ensure connection is closed after displaying books
                if (connect.State == ConnectionState.Open)
                {
                    connect.Close();
                }
            }
        }

        // Handle data grid cell click for editing
        private int bookID = 0;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                bookID = (int)row.Cells[0].Value;
                addBooks_bookTitle.Text = row.Cells[1].Value.ToString();
                addBooks_author.Text = row.Cells[2].Value.ToString();
                addBooks_published.Text = row.Cells[3].Value.ToString();

                string imagePath = row.Cells[4].Value.ToString();

                // Check if the image path is not empty and the file exists before attempting to load it
                if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                {
                    addBooks_picture.Image = Image.FromFile(imagePath);
                }
                else
                {
                    addBooks_picture.Image = null;
                }

                addBooks_status.Text = row.Cells[5].Value.ToString();
            }
        }


        // Clear all input fields
        private void addBooks_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        // Update existing book details
        private void addBooks_updateBtn_Click(object sender, EventArgs e)
        {
            if (bookID == 0 || string.IsNullOrEmpty(addBooks_bookTitle.Text) || string.IsNullOrEmpty(addBooks_author.Text))
            {
                MessageBox.Show("Please select a book to update.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    // Ensure connection is open before update
                    if (connect.State == ConnectionState.Closed)
                    {
                        connect.Open();
                    }

                    DateTime today = DateTime.Today;

                    string updateQuery = "UPDATE books SET book_title = @bookTitle, author = @author, published_date = @publishedDate, " +
                                         "status = @status, date_update = @dateUpdate WHERE id = @id";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, connect))
                    {
                        cmd.Parameters.AddWithValue("@bookTitle", addBooks_bookTitle.Text.Trim());
                        cmd.Parameters.AddWithValue("@author", addBooks_author.Text.Trim());
                        cmd.Parameters.AddWithValue("@publishedDate", addBooks_published.Value);
                        cmd.Parameters.AddWithValue("@status", addBooks_status.Text.Trim());
                        cmd.Parameters.AddWithValue("@dateUpdate", today);
                        cmd.Parameters.AddWithValue("@id", bookID);

                        cmd.ExecuteNonQuery();
                        displayBooks();

                        MessageBox.Show("Book updated successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        clearFields();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // Ensure connection is closed properly after update
                    if (connect.State == ConnectionState.Open)
                    {
                        connect.Close();
                    }
                }
            }
        }

        // Delete book
        private void addBooks_deleteBtn_Click(object sender, EventArgs e)
        {
            if (bookID == 0)
            {
                MessageBox.Show("Please select a book to delete.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    // Ensure connection is open before deletion
                    if (connect.State == ConnectionState.Closed)
                    {
                        connect.Open();
                    }

                    DateTime today = DateTime.Today;

                    string deleteQuery = "UPDATE books SET date_delete = @dateDelete WHERE id = @id";

                    using (SqlCommand cmd = new SqlCommand(deleteQuery, connect))
                    {
                        cmd.Parameters.AddWithValue("@dateDelete", today);
                        cmd.Parameters.AddWithValue("@id", bookID);

                        cmd.ExecuteNonQuery();
                        displayBooks();

                        MessageBox.Show("Book deleted successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        clearFields();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    // Ensure connection is closed properly after deletion
                    if (connect.State == ConnectionState.Open)
                    {
                        connect.Close();
                    }
                }
            }
        }

        private void AddBooks_Load(object sender, EventArgs e)
        {
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
