﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class StudentForm : Form
    {
        SqlConnection connect = new SqlConnection(
            @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\God is Good\OneDrive\Documents\System.mdf;Integrated Security=True");

        public StudentForm()
        {
            InitializeComponent();
        }

        private void StudentForm_Load(object sender, EventArgs e)
        {
            textBox1.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string studentId = textBox1.Text.Trim();

            if (string.IsNullOrEmpty(studentId))
            {
                MessageBox.Show("Please enter student ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                connect.Open();
                string query = "SELECT * FROM students WHERE student_id = @studentId";
                using (SqlCommand cmd = new SqlCommand(query, connect))
                {
                    cmd.Parameters.AddWithValue("@studentId", studentId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        lbl_Firstname.Text = reader["first_name"].ToString();
                        lbl_Middleinitial.Text = reader["middle_initial"].ToString();
                        lbl_Lastname.Text = reader["last_name"].ToString();
                        lbl_Datetimein.Text = reader["datetime_in"].ToString();

                        string imagePath = reader["picture_path"].ToString();

                        if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                        {
                            pictureBoxStudent.Image = Image.FromFile(imagePath);
                        }
                        else
                        {
                            pictureBoxStudent.Image = null;
                            MessageBox.Show("Trying to load image from:\n" + imagePath);
                            MessageBox.Show("Image file not found:\n" + imagePath, "Image Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }



                        // After 5 seconds, go back to SelectForm
                        Timer closeTimer = new Timer();
                        closeTimer.Interval = 5000; // 5 seconds
                        closeTimer.Tick += (s, args) =>
                        {
                            closeTimer.Stop();
                            SelectForm select = new SelectForm();
                            select.Show();
                            this.Hide();
                        };
                        closeTimer.Start();
                    }
                    else
                    {
                        MessageBox.Show("Student not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        pictureBoxStudent.Image = null;
                        lbl_Firstname.Text = "";
                        lbl_Middleinitial.Text = "";
                        lbl_Lastname.Text = "";
                        lbl_Datetimein.Text = "";
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connect.Close();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Optional label click handler
        }
    }
}
