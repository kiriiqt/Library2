﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace LibraryManagementSystem
{
    class DataIssueBooks
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\God is Good\OneDrive\Documents\System.mdf;Integrated Security=True;Connect Timeout=30");

        public int ID { get; set; }
        public string IssueId { get; set; }
        public string FullName { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public string BookTitle { get; set; }
        public string Author { get; set; }
        public string DateIssue { get; set; }
        public string DateReturn { get; set; }
        public string Status { get; set; }

        public List<DataIssueBooks> IssueBooksData()
        {
            List<DataIssueBooks> listData = new List<DataIssueBooks>();
            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();

                    string selectData = "SELECT * FROM issues WHERE date_delete IS NULL";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            DataIssueBooks dib = new DataIssueBooks
                            {
                                ID = Convert.ToInt32(reader["id"]),
                                IssueId = reader["issue_id"].ToString(),
                                FullName = reader["full_name"].ToString(),
                                Contact = reader["contact"].ToString(),
                                Email = reader["email"].ToString(),
                                BookTitle = reader["book_title"].ToString(),
                                Author = reader["author"].ToString(),
                                DateIssue = reader["issue_date"].ToString(),
                                DateReturn = reader["return_date"].ToString(),
                                Status = reader["status"].ToString()
                            };

                            listData.Add(dib);
                        }

                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }

            return listData;
        }

        public List<DataIssueBooks> ReturnIssueBooksData()
        {
            List<DataIssueBooks> listData = new List<DataIssueBooks>();
            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();

                    string selectData = "SELECT * FROM issues WHERE status = 'Not Return' AND date_delete IS NULL";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {
                            DataIssueBooks dib = new DataIssueBooks
                            {
                                ID = Convert.ToInt32(reader["id"]),
                                IssueId = reader["issue_id"].ToString(),
                                FullName = reader["full_name"].ToString(),
                                Contact = reader["contact"].ToString(),
                                Email = reader["email"].ToString(),
                                BookTitle = reader["book_title"].ToString(),
                                Author = reader["author"].ToString(),
                                DateIssue = reader["issue_date"].ToString(),
                                DateReturn = reader["return_date"].ToString(),
                                Status = reader["status"].ToString()
                            };

                            listData.Add(dib);
                        }

                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }

            return listData;
        }
    }
}
