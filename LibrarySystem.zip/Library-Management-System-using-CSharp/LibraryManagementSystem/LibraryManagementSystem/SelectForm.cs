﻿// SelectForm.cs
using System;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class SelectForm : Form
    {
        public SelectForm()
        {
            InitializeComponent();
        }

        private void btnStudent_Click(object sender, EventArgs e)
        {
            StudentForm studentForm = new StudentForm();
            studentForm.Show();
            this.Hide();  // Hide SelectForm
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Hide();  // Hide SelectForm
        }

        private void btnLibrarian_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Hide();  // Hide SelectForm
        }
    }
}
