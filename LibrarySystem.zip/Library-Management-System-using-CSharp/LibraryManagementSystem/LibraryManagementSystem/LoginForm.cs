﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.VisualBasic;

namespace LibraryManagementSystem
{
    public partial class LoginForm : Form
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\God is Good\OneDrive\Documents\System.mdf;Integrated Security=True;Connect Timeout=30");
        Timer idleTimer = new Timer(); // Availability

        public LoginForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void signupBtn_Click(object sender, EventArgs e)
        {
            RegisterForm rForm = new RegisterForm();
            rForm.Show();
            this.Hide();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            login_password.PasswordChar = login_showPass.Checked ? '\0' : '*';
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            if (login_username.Text == "" || login_password.Text == "")
            {
                MessageBox.Show("Please fill all blank fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();
                    string selectData = "SELECT * FROM users WHERE username = @username AND password = @password";
                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        cmd.Parameters.AddWithValue("@username", login_username.Text.Trim());
                        cmd.Parameters.AddWithValue("@password", login_password.Text.Trim());

                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        DataTable table = new DataTable();
                        adapter.Fill(table);

                        if (table.Rows.Count >= 1)
                        {
                            string username = table.Rows[0]["username"].ToString();
                            string email = table.Rows[0]["email"].ToString();

                            if (!string.IsNullOrWhiteSpace(email) && email.Contains("@"))
                            {
                                string otp = new Random().Next(1000, 9999).ToString();
                                SendOtpToEmail(email, otp);

                                string enteredOtp = Interaction.InputBox("A 4-digit OTP was sent to your email. Enter it here:", "OTP Verification", "");

                                if (enteredOtp != otp)
                                {
                                    MessageBox.Show("Invalid OTP. Access denied.", "Security Alert", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                                }

                                LogAction(username, "Admin logged in");
                                MessageBox.Show("Login successful!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                MainForm mainForm = new MainForm();
                                mainForm.Show();
                                this.Hide();

                                StartIdleTimer();
                            }
                            else
                            {
                                MessageBox.Show("No valid email found for this user. Please contact admin.", "Email Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Connection error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        private void LoginForm_Load(object sender, EventArgs e) { }

        private void SendOtpToEmail(string recipientEmail, string otp)
        {
            try
            {
                MailMessage message = new MailMessage();
                message.From = new MailAddress("your_email@gmail.com"); // your Gmail
                message.To.Add(recipientEmail);
                message.Subject = "Your Admin Login OTP";
                message.Body = $"Your one-time 4-digit OTP is: {otp}";

                SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
                // Example already in your code
                smtp.Credentials = new NetworkCredential("tan839075@gmail.com", "kivkysnifcdutrou");
                smtp.EnableSsl = true;
                smtp.Send(message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to send OTP: " + ex.Message, "Email Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void LogAction(string user, string action)
        {
            string log = $"{DateTime.Now}: [{user}] - {action}";
            File.AppendAllText("audit_log.txt", log + Environment.NewLine);
        }

        private void StartIdleTimer()
        {
            idleTimer.Interval = 600000; // 10 minutes
            idleTimer.Tick += IdleTimer_Tick;
            idleTimer.Start();
        }

        private void IdleTimer_Tick(object sender, EventArgs e)
        {
            idleTimer.Stop();
            MessageBox.Show("Session timed out due to inactivity.", "Timeout", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            Application.Restart();
        }
    }
}
