﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LibraryManagementSystem
{
    public partial class ReturnBooks : UserControl
    {
        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\God is Good\OneDrive\Documents\System.mdf;Integrated Security=True;Connect Timeout=30");

        public ReturnBooks()
        {
            InitializeComponent();
            displayIssuedBooksData();
        }

        public void refreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }

            displayIssuedBooksData();
        }

        private void returnBooks_returnBtn_Click(object sender, EventArgs e)
        {
            if (returnBooks_issueID.Text == ""
                || returnBooks_name.Text == ""
                || returnBooks_contact.Text == ""
                || returnBooks_email.Text == ""
                || returnBooks_bookTitle.Text == ""
                || returnBooks_author.Text == ""
                || string.IsNullOrWhiteSpace(bookIssue_issueDate.Text))
            {
                MessageBox.Show("Please select item first", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult check = MessageBox.Show("Are you sure that Issue ID: "
                + returnBooks_issueID.Text.Trim() + " is returned already?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (check == DialogResult.Yes)
            {
                try
                {
                    connect.Open();

                    string updateData = "UPDATE issues SET status = @status, date_update = @dateUpdate " +
    "WHERE issue_id = @issueID";


                    using (SqlCommand cmd = new SqlCommand(updateData, connect))
                    {
                        cmd.Parameters.AddWithValue("@status", "Return");
                        cmd.Parameters.AddWithValue("@dateUpdate", DateTime.Today);
                        cmd.Parameters.AddWithValue("@issueID", returnBooks_issueID.Text);

                        cmd.ExecuteNonQuery();
                    }

                    displayIssuedBooksData();
                    MessageBox.Show("Returned successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    clearFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        public void displayIssuedBooksData()
        {
            DataIssueBooks dib = new DataIssueBooks();
            List<DataIssueBooks> listData = dib.ReturnIssueBooksData();
            dataGridView1.DataSource = listData;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                returnBooks_issueID.Text = row.Cells[1].Value.ToString(); // issue_id
                returnBooks_name.Text = row.Cells[2].Value.ToString();    // full_name
                returnBooks_contact.Text = row.Cells[3].Value.ToString(); // contact
                returnBooks_email.Text = row.Cells[11].Value.ToString();  // email
                returnBooks_bookTitle.Text = row.Cells[4].Value.ToString(); // book_title
                returnBooks_author.Text = row.Cells[5].Value.ToString();  // author
                bookIssue_issueDate.Text = row.Cells[13].Value.ToString(); // issue_date

            }
        }

        public void clearFields()
        {
            returnBooks_issueID.Clear();
            returnBooks_name.Clear();
            returnBooks_contact.Clear();
            returnBooks_email.Clear();
            returnBooks_bookTitle.Clear();
            returnBooks_author.Clear();
            bookIssue_issueDate.Text = "";
        }

        private void returnBooks_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            // Optional: custom drawing on the panel
        }

        private void ReturnBooks_Load(object sender, EventArgs e)
        {
            // Optional: add custom load behavior
        }
    }
}
