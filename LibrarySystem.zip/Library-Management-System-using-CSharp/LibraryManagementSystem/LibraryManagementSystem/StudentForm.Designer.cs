﻿namespace LibraryManagementSystem
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lbl_Firstname = new System.Windows.Forms.Label();
            this.lbl_Middleinitial = new System.Windows.Forms.Label();
            this.lbl_Lastname = new System.Windows.Forms.Label();
            this.lbl_Datetimein = new System.Windows.Forms.Label();
            this.pictureBoxStudent = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStudent)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(200, 170);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(116, 34);
            this.textBox1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(226, 210);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "LOGIN";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbl_Firstname
            // 
            this.lbl_Firstname.AutoSize = true;
            this.lbl_Firstname.ForeColor = System.Drawing.Color.White;
            this.lbl_Firstname.Location = new System.Drawing.Point(164, 259);
            this.lbl_Firstname.Name = "lbl_Firstname";
            this.lbl_Firstname.Size = new System.Drawing.Size(35, 13);
            this.lbl_Firstname.TabIndex = 2;
            this.lbl_Firstname.Text = "Name";
            this.lbl_Firstname.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_Middleinitial
            // 
            this.lbl_Middleinitial.AutoSize = true;
            this.lbl_Middleinitial.ForeColor = System.Drawing.Color.White;
            this.lbl_Middleinitial.Location = new System.Drawing.Point(247, 259);
            this.lbl_Middleinitial.Name = "lbl_Middleinitial";
            this.lbl_Middleinitial.Size = new System.Drawing.Size(41, 13);
            this.lbl_Middleinitial.TabIndex = 3;
            this.lbl_Middleinitial.Text = "MiddleI";
            // 
            // lbl_Lastname
            // 
            this.lbl_Lastname.AutoSize = true;
            this.lbl_Lastname.ForeColor = System.Drawing.Color.White;
            this.lbl_Lastname.Location = new System.Drawing.Point(323, 259);
            this.lbl_Lastname.Name = "lbl_Lastname";
            this.lbl_Lastname.Size = new System.Drawing.Size(53, 13);
            this.lbl_Lastname.TabIndex = 4;
            this.lbl_Lastname.Text = "Lastname";
            // 
            // lbl_Datetimein
            // 
            this.lbl_Datetimein.AutoSize = true;
            this.lbl_Datetimein.ForeColor = System.Drawing.Color.White;
            this.lbl_Datetimein.Location = new System.Drawing.Point(247, 312);
            this.lbl_Datetimein.Name = "lbl_Datetimein";
            this.lbl_Datetimein.Size = new System.Drawing.Size(30, 13);
            this.lbl_Datetimein.TabIndex = 5;
            this.lbl_Datetimein.Text = "Date";
            // 
            // pictureBoxStudent
            // 
            this.pictureBoxStudent.Location = new System.Drawing.Point(200, 59);
            this.pictureBoxStudent.Name = "pictureBoxStudent";
            this.pictureBoxStudent.Size = new System.Drawing.Size(116, 95);
            this.pictureBoxStudent.TabIndex = 6;
            this.pictureBoxStudent.TabStop = false;
            // 
            // StudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(543, 387);
            this.Controls.Add(this.pictureBoxStudent);
            this.Controls.Add(this.lbl_Datetimein);
            this.Controls.Add(this.lbl_Lastname);
            this.Controls.Add(this.lbl_Middleinitial);
            this.Controls.Add(this.lbl_Firstname);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "StudentForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StudentForm";
            this.Load += new System.EventHandler(this.StudentForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStudent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbl_Firstname;
        private System.Windows.Forms.Label lbl_Middleinitial;
        private System.Windows.Forms.Label lbl_Lastname;
        private System.Windows.Forms.Label lbl_Datetimein;
        private System.Windows.Forms.PictureBox pictureBoxStudent;
    }
}