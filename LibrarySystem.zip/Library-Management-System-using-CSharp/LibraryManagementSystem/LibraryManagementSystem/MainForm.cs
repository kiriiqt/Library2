﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class MainForm : Form
    {
        // 🔒 Auto-lock system variables
        private Timer idleTimer = new Timer();
        private DateTime lastActivity = DateTime.Now;

        public MainForm()
        {
            InitializeComponent();
        }

        // 🔒 Setup the idle timer when the form loads
        private void MainForm_Load(object sender, EventArgs e)
        {
            SetupIdleTimer();
        }

        // 🔒 Start monitoring for inactivity
        private void SetupIdleTimer()
        {
            idleTimer.Interval = 1000; // check every 1 second
            idleTimer.Tick += IdleTimer_Tick;
            idleTimer.Start();
        }

        // 🔒 Auto-lock after 10 minutes of no activity
        private void IdleTimer_Tick(object sender, EventArgs e)
        {
            if ((DateTime.Now - lastActivity).TotalMinutes >= 10)
            {
                idleTimer.Stop();
                MessageBox.Show("System locked due to inactivity. Please log in again.", "Auto Lock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Application.Restart(); // you can change this to show a lock form instead
            }
        }

        // 🔒 Track mouse movement to reset idle time
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            lastActivity = DateTime.Now;
        }

        // 🔒 Track key press to reset idle time
        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            lastActivity = DateTime.Now;
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logout_btn_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("Are you sure you want to logout?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (check == DialogResult.Yes)
            {
                LoginForm lForm = new LoginForm();
                lForm.Show();
                this.Hide();
            }
        }

        private void dashboard_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = true;
            addBooks1.Visible = false;
            returnBooks1.Visible = false;
            issueBooks1.Visible = false;

            Dashboard dForm = dashboard1 as Dashboard;
            if (dForm != null)
            {
                dForm.refreshData();
            }
        }

        private void addBooks_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = false;
            addBooks1.Visible = true;
            returnBooks1.Visible = false;
            issueBooks1.Visible = false;

            AddBooks aForm = addBooks1 as AddBooks;
            if (aForm != null)
            {
                aForm.refreshData();
            }
        }

        private void issueBooks_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = false;
            addBooks1.Visible = false;
            returnBooks1.Visible = false;
            issueBooks1.Visible = true;

            ReturnBooks rForm = returnBooks1 as ReturnBooks;
            if (rForm != null)
            {
                rForm.refreshData();
            }
        }

        private void returnBooks_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = false;
            addBooks1.Visible = false;
            returnBooks1.Visible = true;
            issueBooks1.Visible = false;

            IssueBooks iForm = issueBooks1 as IssueBooks;
            if (iForm != null)
            {
                iForm.refreshData();
            }
        }
        private void dashboard1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
      
    }
}
