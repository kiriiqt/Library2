﻿SELECT *FROM users

SELECT *FROM books
DELETE FROM books

SELECT * FROM issues
DELETE FROM issues